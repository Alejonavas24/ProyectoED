package EstructurasDeDatos;

public class Arbol {
    public NodoArbol raiz;
    public Arbol() {
        raiz=null;
    }

    public void Insertar(String Key,Object contenido){
        NodoArbol nuevo = new NodoArbol(Key,contenido);
        if(raiz==null){
            raiz=nuevo;
        }else{
            NodoArbol auxiliar=raiz;
            NodoArbol padre;
            while(true){
                padre=auxiliar;
                if(Key.compareTo(auxiliar.Llave) < 0){
                    auxiliar=auxiliar.HijoIzquieerrda;
                    if(auxiliar==null){
                        padre.HijoIzquieerrda=nuevo;
                        return;
                    }
                }else{
                    auxiliar=auxiliar.HijoDerecha;
                    if(auxiliar==null){
                        padre.HijoDerecha=nuevo;
                        return;
                    }
                }
            }
        }


    }
    public boolean IsEmpty(){
        return raiz==null;
    }
    public void recorrer (NodoArbol r ){
        if(r!=null){
            recorrer(r.HijoIzquieerrda);
            System.out.println(r.Llave);
            recorrer(r.HijoDerecha);
        }
    }
    public String BuscarNodo (String d){
        NodoArbol aux=raiz;
        while(d.compareTo(aux.Llave)!=0){
            if (d.compareTo(aux.Llave)<0){
                aux=aux.HijoIzquieerrda;
            }else{
                aux=aux.HijoDerecha;
            }
            if(aux==null){
                return null;
            }
        }
        String finalisimo= aux.Llave+","+aux.ObtenerValor();
        return finalisimo;
    }
    public boolean Eliminar(String key){
        NodoArbol auxiliar=raiz;
        NodoArbol paadre=raiz;
        boolean esHijoIzq=true;
        while(key.compareTo(auxiliar.Llave) !=0){
            paadre=auxiliar;
            if(key.compareTo(auxiliar.Llave) < 0){
                esHijoIzq=true;
                auxiliar=auxiliar.HijoIzquieerrda;
            }
            else{
                esHijoIzq=false;
                auxiliar=auxiliar.HijoDerecha;
            }
            if(auxiliar==null){
                return false;
            }
        }//fin while
        if(auxiliar.HijoIzquieerrda==null && auxiliar.HijoDerecha==null){
            if(auxiliar==raiz){
                raiz=null;
            }
            else if(esHijoIzq){
                paadre.HijoIzquieerrda=null;
            }else{
                paadre.HijoDerecha=null;
            }
        }else if (auxiliar.HijoDerecha==null){
            if(auxiliar==raiz){
                raiz=auxiliar.HijoIzquieerrda;
            }
            else if(esHijoIzq){
                paadre.HijoIzquieerrda=auxiliar.HijoIzquieerrda;
            }else{
                paadre.HijoDerecha=auxiliar.HijoIzquieerrda;
            }
        }
        else if (auxiliar.HijoIzquieerrda==null){
            if(auxiliar==raiz){
                raiz=auxiliar.HijoDerecha;
            }
            else if(esHijoIzq){
                paadre.HijoIzquieerrda=auxiliar.HijoDerecha;
            }else{
                paadre.HijoDerecha=auxiliar.HijoIzquieerrda;
            }

        }else{
            NodoArbol reemplazo=obtenerNodoReemplazo(auxiliar);
            if(auxiliar==raiz){raiz=reemplazo;}
            else if(esHijoIzq){paadre.HijoIzquieerrda=reemplazo;}
            else{paadre.HijoDerecha=reemplazo;}
            reemplazo.HijoIzquieerrda=auxiliar.HijoIzquieerrda;
        }
        return true;
    }


    public NodoArbol obtenerNodoReemplazo(NodoArbol nodoRemp){
        NodoArbol remplazarpadre=nodoRemp;
        NodoArbol reemplazo=nodoRemp;
        NodoArbol auxiliar=nodoRemp.HijoDerecha;
        while(auxiliar != null){
            remplazarpadre=reemplazo;
            reemplazo=auxiliar;
            auxiliar=auxiliar.HijoIzquieerrda;
        }
        if(reemplazo!=nodoRemp.HijoDerecha){
            remplazarpadre.HijoIzquieerrda=reemplazo.HijoDerecha;
            reemplazo.HijoDerecha=nodoRemp.HijoDerecha;
        }
        return reemplazo;
    }
}
