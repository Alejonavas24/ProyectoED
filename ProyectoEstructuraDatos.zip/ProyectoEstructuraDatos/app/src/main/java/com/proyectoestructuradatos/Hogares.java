package com.proyectoestructuradatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import Logica.HogaresLogica;


public class Hogares extends AppCompatActivity {
    public HogaresLogica casas=new HogaresLogica();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hogares);
        String registro=getIntent().getStringExtra("info");
        if(registro!=null){
        casas.postulatuhogar("Manuel,UN,3013187435");
            casas.postulatuhogar(registro);
    }
    }
    public void CambioRegistro(View view){
        Intent CambioHogares=new Intent(this,RegistroHogares.class);
        startActivity(CambioHogares);
    }
    public void ObtenerHogar(View view){
        Intent Encontrar=new Intent(this,ObtenHogar.class);
        String ola=casas.encuentraunhogar();
        Encontrar.putExtra("retorno",ola);
        startActivity(Encontrar);
    }
}