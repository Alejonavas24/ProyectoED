package com.proyectoestructuradatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import Logica.HogaresLogica;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        HogaresLogica casas=new HogaresLogica();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void ActivityHogares(View view){
        Intent CambioHogares=new Intent(this,Hogares.class);
        startActivity(CambioHogares);
    }
    public void ActivityTuurnos(View view){
        Intent CambioHogares=new Intent(this,Turnos.class);
        startActivity(CambioHogares);

}
    public void Activitybusqueda(View view){
        Intent busqueda=new Intent(this,BusquedaMascoats.class);
        startActivity(busqueda);
}
}