package com.proyectoestructuradatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import Logica.BusquedaLogica;

public class BusquedaMascoats extends AppCompatActivity {
    BusquedaLogica arbolito=new BusquedaLogica();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_busqueda_mascoats);


    }

    public void registrarmascota(View view){
        EditText cuadronombre=findViewById(R.id.cnombremascota);
        EditText cuandrodescripcion=findViewById(R.id.descripcionmascota);
        String Name= cuadronombre.getText().toString();
        String descripcion=cuandrodescripcion.getText().toString();
        arbolito.PublicarMascotas(Name,descripcion);
        Toast.makeText(this, "Mascota publicada exitosamente ", Toast.LENGTH_SHORT).show();
        cuadronombre.setText("");
        cuandrodescripcion.setText("");
    }
    public void buscarmascota(View view){
        EditText cuadronombre=findViewById(R.id.cnombremascota);
        EditText cuandrodescripcion=findViewById(R.id.descripcionmascota);
        String Name=cuadronombre.getText().toString();
        String resultado=arbolito.BuscarMascota(Name);
        if (resultado!=null){
            String[] publicacion=resultado.split(",");
            cuadronombre.setText(publicacion[0]);
            cuandrodescripcion.setText(publicacion[1]);
        }
    }

    public void inicio(View view){
        Intent inicio=new Intent(this,MainActivity.class);
        startActivity(inicio);
    }
}