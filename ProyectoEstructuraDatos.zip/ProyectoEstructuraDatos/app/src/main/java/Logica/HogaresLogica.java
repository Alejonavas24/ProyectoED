package Logica;
import EstructurasDeDatos.Stack;

import android.util.Log;
import android.widget.Toast;

import com.proyectoestructuradatos.Hogares;
import com.proyectoestructuradatos.RegistroHogares;

import java.io.Serializable;
import java.util.Scanner;

public class HogaresLogica implements Serializable {
    Stack lugares = new Stack();
    String datos;
    public HogaresLogica(){
        datos =null;   }
    public void postulatuhogar(String casa){
        datos=casa;
        lugares.push(datos);
    }
    public String encuentraunhogar(){
        if(!lugares.empty()) {
            String retorno=lugares.pop();
            return retorno;
        }else{
            String nohay="No hay lugares disponibles en este momento :(";
                Log.d("vacio",nohay);
            return nohay;
        }

    }
}
